import { useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import { Counter } from "./Components/Counter";
import { Todo } from "./Components/Todo/Todo";

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="App">
      <Counter />
      <br />
      <br />
      <Todo />
    </div>
  );
}

export default App;
