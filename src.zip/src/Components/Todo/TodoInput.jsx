import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addTodos, getTodos } from "../../Redux/todos/action";

export const TodoInput = () => {
  const [text, setText] = useState("");
  const dispatch = useDispatch();

  const handleAddTodo = () => {
    dispatch(
      addTodos({
        title: text,
      })
    ).then(() => {
      dispatch(getTodos());
    });
  };

  return (
    <div>
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="add a task"
      />
      <button onClick={handleAddTodo}>ADD</button>
    </div>
  );
};
