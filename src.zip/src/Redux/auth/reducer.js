const initState = {
  isAuth: true,
  token: "ABCD",
};

export const authReducer = (state = initState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};
